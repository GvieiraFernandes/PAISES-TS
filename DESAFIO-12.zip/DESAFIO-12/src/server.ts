import { MongoClient } from "mongodb";
import getMongoConn from "./db";
import cors from "cors";
import express, { Request, Response } from "express";
import PaisesInfo from "./models/pais.js";


const port = 3000;
const app = express();


app.use(cors());
app.use(express.json());

app.get("/paises", async (req: Request, res: Response) => {
    const { populacao } = req.query;
    try {
        if (typeof populacao !== "string") {
            throw new Error("Parâmetro população não foi informado!");
        }
        let populacaoNumber = parseInt(populacao)
        if (isNaN(populacaoNumber)) {
            throw new Error("Parâmetropopulacao não é valido!");
        }
        let conn: MongoClient | null = null;
        try {
            conn = await getMongoConn();
            const db = conn.db();
            const paises = db.collection("paises");
            const paisesFiltrados = await paises.find({
                populacao: { $gte: populacaoNumber }
            }).toArray();
            res.status(200).json(paisesFiltrados);
        }
        catch (err) {
            res.status(500).json({ message:(err as Error).message})

        }
        finally {
            conn?.close()
        }
        
    }
    catch (err) {
        res.status(400).json({ message: (err as Error).message})

    } 
});

app.post("/paises", async (req: Request, res: Response) => {
    const record = req.body;
    try {
        if (!record.nome) {
            throw new Error("O atributo nome não foi informado");
        }
        if (!record.populacao) {
            throw new Error("O atributo populacao não foi informado");
        }
        if (typeof record.nome !== "string") {
            throw new Error("O atributo nome é invalido");
        }
        if (typeof record.populacao !== "number") {
            throw new Error("O atributo populacao é invalido");
        }
        const pais = new PaisesInfo(record.nome, record.populacao);
        let conn: MongoClient | null = null;
        try {
            conn = await getMongoConn();
            const db = conn.db();
            const paises = db.collection("paises");
            await paises.insertOne(pais);
            res.status(201).json(pais);
        } catch (err) {
            res.status(500).json({ message: (err as Error).message });
        } finally {
            conn?.close();
        }
    } catch (error) {
        res.status(400).json({ message: (error as Error).message })
    }
});




app.listen(port, () => {
    console.log(`Servidor sendo executado na porta ${port}`);
})