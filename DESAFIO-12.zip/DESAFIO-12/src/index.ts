import { MongoClient } from "mongodb";
import getMongoConn from "./db";
import PaisesInfo from "./models/pais.js"


const main = async () => {
    let conn: MongoClient | null = null;
    try {
        conn = await getMongoConn();
        const db = conn.db();
        const paises = db.collection<PaisesInfo>("paises");
        await paises.deleteMany({})



    

        await paises.insertMany([
            new PaisesInfo("Brasil", 45810000),
            new PaisesInfo("Eatados Unidos", 34500000),
            new PaisesInfo("Portugal", 57000000),
            new PaisesInfo("Grecia", 187000000),
        ]);

        console.log("Paises inseridos com sucesso");
    } catch (err) {
        console.log(err);
    } finally {
        conn?.close()
    }
}

main();

