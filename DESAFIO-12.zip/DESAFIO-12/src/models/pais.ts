

 export default class PaisesInfo{
        nome: string;
        populacao: number;
    
        constructor(nome: string, populacao: number) {
            this.nome = nome;
            this.populacao = populacao;
        }
    }